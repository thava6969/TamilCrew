# TamilCrew
this for tamil movies and tv shows.

please do not do anything with the settings keep as default settings.

this is my own addon so please this is the devlopment version of the tamil crew addon.

we do own or host any of these channels we find these channels from the internet.